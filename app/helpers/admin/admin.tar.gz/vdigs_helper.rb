module VdigsHelper
end
